import socket
import network
import machine
from secrets import secrets
from machine import Pin,PWM,UART,WDT
import time 

ssid = secrets['ssid']
password = secrets['pw']
flag = secrets['flag']

led = machine.Pin("LED",Pin.OUT)

ap = network.WLAN(network.AP_IF)
ap.config(essid=ssid, password=password)
ap.active(True)

while ap.active() == False:
  pass

print('Connection successful')
print(ap.ifconfig()) 

def generateHTML():
    html = """<!DOCTYPE html>
    <html>
        <head> 
            <title>WELCOME TO BSIDES 2023!</title> 
            <style>
            button {
                width:175px;
                height:100px;
                background-color:#0000ff;
                color:#ffffff;
                font-size:25pt
            }
            </style>
        </head>
        <body>
            """
    html = html + f"""The First Flag is: {flag}
    </body>
        </html>
    """
    return html

addr = socket.getaddrinfo('0.0.0.0', 80)[0][-1]
s = socket.socket()
s.bind(addr)
s.listen(1)

print('listening on', addr)

# Listen for connections
while True:
    led.on()
    try:
        led.toggle()
        #wdt.feed()
        cl, addr = s.accept()
        print('client connected from', addr)
        led.toggle()
        time.sleep(0.2)
        led.toggle()
        request = cl.recv(1024)
        data = str(request)
        direction = (data[1:20].split(' ')[1].replace('/',''))
        
        cl.send('HTTP/1.0 200 OK\r\nContent-type: text/html\r\n\r\n\r\n')
        time.sleep(0.2)
        cl.send(generateHTML())
        cl.close()


    except OSError as e:
        cl.close()
        s.close()
        print(f'{e}')
        blink_error(e)
        print('connection closed')
        restart()